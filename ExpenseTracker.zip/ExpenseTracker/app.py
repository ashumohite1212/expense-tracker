from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import or_
from datetime import datetime
import os

app = Flask(__name__)

# ==============================
# Database Configuration
# ==============================

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

app.config["SQLALCHEMY_DATABASE_URI"] = (
    "sqlite:///" + os.path.join(BASE_DIR, "expenses.db")
)

app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)


# ==============================
# Expense Model
# ==============================

class Expense(db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    title = db.Column(
        db.String(100),
        nullable=False
    )

    amount = db.Column(
        db.Float,
        nullable=False
    )

    category = db.Column(
        db.String(50),
        nullable=False
    )

    date = db.Column(
        db.String(20),
        nullable=False
    )

    description = db.Column(
        db.Text,
        nullable=True
    )


# ==============================
# Home / Dashboard
# ==============================

@app.route("/")
def home():

    search = request.args.get(
        "search",
        ""
    ).strip()

    category = request.args.get(
        "category",
        ""
    ).strip()


    # Start query

    query = Expense.query


    # Search

    if search:

        query = query.filter(
            or_(
                Expense.title.ilike(
                    f"%{search}%"
                ),
                Expense.description.ilike(
                    f"%{search}%"
                )
            )
        )


    # Category filter

    if category:

        query = query.filter(
            Expense.category == category
        )


    # Get expenses

    expenses = query.order_by(
        Expense.id.desc()
    ).all()


    # All expenses for dashboard statistics

    all_expenses = Expense.query.all()


    # Total spending

    total = sum(
        expense.amount
        for expense in all_expenses
    )


    # Number of expenses

    expense_count = len(
        all_expenses
    )


    # Highest expense

    highest_expense = max(
        (expense.amount for expense in all_expenses),
        default=0
    )


    # Current month

    current_month = datetime.now().strftime(
        "%Y-%m"
    )


    monthly_total = sum(
        expense.amount
        for expense in all_expenses
        if expense.date.startswith(current_month)
    )


    return render_template(
        "index.html",
        expenses=expenses,
        total=total,
        expense_count=expense_count,
        highest_expense=highest_expense,
        monthly_total=monthly_total,
        search=search,
        selected_category=category
    )


# ==============================
# Add Expense
# ==============================

@app.route(
    "/add",
    methods=["GET", "POST"]
)
def add_expense():

    if request.method == "POST":

        title = request.form["title"]

        amount = request.form["amount"]

        category = request.form["category"]

        date = request.form["date"]

        description = request.form["description"]


        new_expense = Expense(

            title=title,

            amount=float(amount),

            category=category,

            date=date,

            description=description

        )


        db.session.add(
            new_expense
        )

        db.session.commit()


        return redirect(
            url_for("home")
        )


    return render_template(
        "add_expense.html"
    )


# ==============================
# Edit Expense
# ==============================

@app.route(
    "/edit/<int:id>",
    methods=["GET", "POST"]
)
def edit_expense(id):

    expense = Expense.query.get_or_404(
        id
    )


    if request.method == "POST":

        expense.title = request.form[
            "title"
        ]

        expense.amount = float(
            request.form["amount"]
        )

        expense.category = request.form[
            "category"
        ]

        expense.date = request.form[
            "date"
        ]

        expense.description = request.form[
            "description"
        ]


        db.session.commit()


        return redirect(
            url_for("home")
        )


    return render_template(
        "edit_expense.html",
        expense=expense
    )


# ==============================
# Delete Expense
# ==============================

@app.route(
    "/delete/<int:id>"
)
def delete_expense(id):

    expense = Expense.query.get_or_404(
        id
    )


    db.session.delete(
        expense
    )

    db.session.commit()


    return redirect(
        url_for("home")
    )


# ==============================
# Create Database
# ==============================

with app.app_context():

    db.create_all()


# ==============================
# Run Application
# ==============================

if __name__ == "__main__":

    app.run(
        debug=True
    )